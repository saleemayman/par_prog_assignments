#ifndef PI_SERIES_H_
#define PI_SERIES_H_

double pi_series(long num_terms, long num_threads);

#endif /* PI_SERIES_H_ */
